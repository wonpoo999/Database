-- 테이블 생성

-- 외래키 추가

-- 시퀀스 생성

-- select query

