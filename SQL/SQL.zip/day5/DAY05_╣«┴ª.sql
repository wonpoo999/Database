-- ✅ 0. 기존 객체 제거
DROP TABLE tbl_buy CASCADE CONSTRAINTS;
DROP TABLE tbl_product CASCADE CONSTRAINTS;
DROP TABLE tbl_customer# CASCADE CONSTRAINTS;
DROP SEQUENCE seq_tblbuy;

-- ✅ 1. 고객 테이블 생성
CREATE TABLE tbl_customer# (
  customer_id VARCHAR2(20) NOT NULL,
  name        VARCHAR2(20),
  email       VARCHAR2(30) NOT NULL,
  age         NUMBER(3,0) DEFAULT 0,
  reg_date    DATE DEFAULT SYSDATE,
  PRIMARY KEY (customer_id),
  CONSTRAINT UQ_email UNIQUE (email)
);

-- ✅ 2. 상품 테이블 생성
CREATE TABLE tbl_product (
  pcode    VARCHAR2(20) NOT NULL,
  category CHAR(2)      NOT NULL,
  pname    VARCHAR2(50),
  price    NUMBER,
  PRIMARY KEY (pcode)
);

-- ✅ 3. 구매 테이블 생성 (✅ 컬럼명 수정: quantity)
CREATE TABLE tbl_buy (
  buy_seq     NUMBER       NOT NULL,
  customer_id VARCHAR2(20) NOT NULL,
  pcode       VARCHAR2(20) NOT NULL,
  quantity    NUMBER       NOT NULL,
  buy_date    TIMESTAMP    NOT NULL,
  PRIMARY KEY (buy_seq),
  CONSTRAINT FK_tbl_customer#_TO_tbl_buy FOREIGN KEY (customer_id)
    REFERENCES tbl_customer# (customer_id),
  CONSTRAINT FK_tbl_product_TO_tbl_buy FOREIGN KEY (pcode)
    REFERENCES tbl_product (pcode)
);

-- ✅ 4. 시퀀스 생성
CREATE SEQUENCE seq_tblbuy
  START WITH 2001
  INCREMENT BY 1
  NOCACHE
  NOCYCLE;

-- ✅ 5. COMMENT 주석 추가
COMMENT ON TABLE tbl_customer# IS '고객';
COMMENT ON COLUMN tbl_customer#.reg_date IS '등록날짜';

COMMENT ON TABLE tbl_product IS '상품';
COMMENT ON COLUMN tbl_product.pcode IS '상품코드';
COMMENT ON COLUMN tbl_product.category IS '카테고리';
COMMENT ON COLUMN tbl_product.pname IS '상품명';
COMMENT ON COLUMN tbl_product.price IS '가격';

COMMENT ON TABLE tbl_buy IS '구매';
COMMENT ON COLUMN tbl_buy.buy_seq IS '구매번호';
COMMENT ON COLUMN tbl_buy.customer_id IS '고객_ID';
COMMENT ON COLUMN tbl_buy.pcode IS '상품코드';
COMMENT ON COLUMN tbl_buy.quantity IS '구매수량';
COMMENT ON COLUMN tbl_buy.buy_date IS '구매날짜';

-- ✅ 6. 고객 데이터 입력
INSERT INTO tbl_customer# VALUES ('mina012', '김민아', 'kimm@gmail.com', 20, TO_DATE('2025-03-10 14:23:25', 'YYYY-MM-DD HH24:MI:SS'));
INSERT INTO tbl_customer# VALUES ('hongGD', '홍길동', 'gil@korea.com', 32, TO_DATE('2023-10-21 11:12:23', 'YYYY-MM-DD HH24:MI:SS'));
INSERT INTO tbl_customer# VALUES ('twice', '박모모', 'momo@daum.net', 29, TO_DATE('2024-12-25 19:23:45', 'YYYY-MM-DD HH24:MI:SS'));
INSERT INTO tbl_customer# VALUES ('wonder', '이나나', 'lee@naver.com', NULL, TO_DATE('2024-12-31 23:58:59', 'YYYY-MM-DD HH24:MI:SS'));

-- ✅ 7. 상품 데이터 입력
INSERT INTO tbl_product VALUES ('DOWON123a', 'B2', '동언참치선물세트', 54000);
INSERT INTO tbl_product VALUES ('CJBAb12g', 'B1', '햇반 12개입', 14500);
INSERT INTO tbl_product VALUES ('JINRMn5', 'B1', '진라면 5개입', 6350);
INSERT INTO tbl_product VALUES ('APLE5kg', 'A1', '청송사과 5kg', 28500);
INSERT INTO tbl_product VALUES ('MANGOTK4r', 'A2', '애플망고 1kg', 32000);

-- ✅ 8. 구매 데이터 입력 (시퀀스 사용)
INSERT INTO tbl_buy (buy_seq, customer_id, pcode, quantity, buy_date)
VALUES (seq_tblbuy.NEXTVAL, 'mina012', 'CJBAb12g', 2, TO_TIMESTAMP('2025-01-15 14:33:15', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO tbl_buy (buy_seq, customer_id, pcode, quantity, buy_date)
VALUES (seq_tblbuy.NEXTVAL, 'mina012', 'APLE5kg', 2, TO_TIMESTAMP('2024-11-04 14:33:15', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO tbl_buy (buy_seq, customer_id, pcode, quantity, buy_date)
VALUES (seq_tblbuy.NEXTVAL, 'mina012', 'JINRMn5', 3, TO_TIMESTAMP('2025-01-10 14:33:15', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO tbl_buy (buy_seq, customer_id, pcode, quantity, buy_date)
VALUES (seq_tblbuy.NEXTVAL, 'twice', 'JINRMn5', 2, TO_TIMESTAMP('2025-01-21 14:33:15', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO tbl_buy (buy_seq, customer_id, pcode, quantity, buy_date)
VALUES (seq_tblbuy.NEXTVAL, 'twice', 'MANGOTK4r', 2, TO_TIMESTAMP('2025-01-26 14:33:15', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO tbl_buy (buy_seq, customer_id, pcode, quantity, buy_date)
VALUES (seq_tblbuy.NEXTVAL, 'hongGD', 'DOWON123a', 1, TO_TIMESTAMP('2025-01-03 09:33:15', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO tbl_buy (buy_seq, customer_id, pcode, quantity, buy_date)
VALUES (seq_tblbuy.NEXTVAL, 'hongGD', 'APLE5kg', 1, TO_TIMESTAMP('2025-01-06 14:33:15', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO tbl_buy (buy_seq, customer_id, pcode, quantity, buy_date)
VALUES (seq_tblbuy.NEXTVAL, 'hongGD', 'DOWON123a', 1, TO_TIMESTAMP('2025-01-03 09:33:15', 'YYYY-MM-DD HH24:MI:SS'));


-- ✅ 문제 1) age >= 30 인 고객 전체 조회
PROMPT 📌 문제 1) age >= 30 인 고객 전체 조회

PROMPT 💡 입력코드
PROMPT SELECT * FROM tbl_customer# WHERE age >= 30;

SELECT * FROM tbl_customer#
WHERE age >= 30;

--

-- ✅ 문제 2) customer_id = 'twice' 인 고객 이메일 조회
PROMPT 📌 문제 2) customer_id = 'twice' 인 고객 이메일 조회

PROMPT 💡 입력코드
PROMPT SELECT email FROM tbl_customer# WHERE customer_id = 'twice';

SELECT email 
FROM tbl_customer#
WHERE customer_id = 'twice';

--

-- ✅ 문제 3) category = 'A2' 인 상품명 조회
PROMPT 📌 문제 3) category = 'A2' 인 상품명 조회

PROMPT 💡 입력코드
PROMPT SELECT pname FROM tbl_product WHERE category = 'A2';

SELECT pname 
FROM tbl_product
WHERE category = 'A2';

--

-- ✅ 문제 4) 상품 가격의 최대값 조회
PROMPT 📌 문제 4) 상품 가격의 최대값 조회

PROMPT 💡 입력코드
PROMPT SELECT MAX(price) AS 최고가격 FROM tbl_product;

SELECT MAX(price) AS 최고가격
FROM tbl_product;

--

-- ✅ 문제 5) 'JINRMn5' 상품의 총 구매수량 조회
PROMPT 📌 문제 5) 'JINRMn5' 상품의 총 구매수량 조회

PROMPT 💡 입력코드
PROMPT SELECT SUM(quantity) AS 총구매수량 FROM tbl_buy WHERE pcode = 'JINRMn5';

SELECT SUM(quantity) AS 총구매수량
FROM tbl_buy
WHERE pcode = 'JINRMn5';

--

-- ✅ 문제 6) 'mina012' 고객의 구매기록 전체 조회
PROMPT 📌 문제 6) 'mina012' 고객의 구매기록 전체 조회

PROMPT 💡 입력코드
PROMPT SELECT * FROM tbl_buy WHERE customer_id = 'mina012';

SELECT * 
FROM tbl_buy
WHERE customer_id = 'mina012';

--

-- ✅ 문제 7) pcode에 '0' 포함된 구매상품 조회
PROMPT 📌 문제 7) pcode에 '0' 포함된 구매상품 조회

PROMPT 💡 입력코드
PROMPT SELECT * FROM tbl_buy WHERE pcode LIKE '%0%';

SELECT * 
FROM tbl_buy
WHERE pcode LIKE '%0%';

--

-- ✅ 문제 8) pcode에 'on' 포함된 구매상품 조회
PROMPT 📌 문제 8) pcode에 'on' 포함된 구매상품 조회

PROMPT 💡 입력코드
PROMPT SELECT * FROM tbl_buy WHERE LOWER(pcode) LIKE '%on%';

SELECT * 
FROM tbl_buy
WHERE LOWER(pcode) LIKE '%on%';

--

-- ✅ 문제 9) 2024년 구매 고객 ID, 이름, 날짜 조회
PROMPT 📌 문제 9) 2024년 구매 고객 ID, 이름, 날짜 조회

PROMPT 💡 입력코드
PROMPT SELECT c.customer_id, c.name, b.buy_date 
PROMPT FROM tbl_customer# c JOIN tbl_buy b ON c.customer_id = b.customer_id 
PROMPT WHERE TO_CHAR(b.buy_date, 'YYYY') = '2024';

SELECT c.customer_id, c.name, b.buy_date
FROM tbl_customer# c
JOIN tbl_buy b ON c.customer_id = b.customer_id
WHERE TO_CHAR(b.buy_date, 'YYYY') = '2024';

--

-- ✅ 문제 10) 'twice'의 구매 상품명, 단가, 구매금액 조회
PROMPT 📌 문제 10) 'twice'의 구매 상품명, 단가, 구매금액 조회

PROMPT 💡 입력코드
PROMPT SELECT p.pname, p.price, (p.price * b.quantity) AS 구매금액 
PROMPT FROM tbl_buy b JOIN tbl_product p ON b.pcode = p.pcode 
PROMPT WHERE b.customer_id = 'twice';

SELECT p.pname, p.price, (p.price * b.quantity) AS 구매금액
FROM tbl_buy b
JOIN tbl_product p ON b.pcode = p.pcode
WHERE b.customer_id = 'twice';

